module.exports = {
    404: {
        id: '404',
        description: 'Alamat tidak ditemukan'
    }
}